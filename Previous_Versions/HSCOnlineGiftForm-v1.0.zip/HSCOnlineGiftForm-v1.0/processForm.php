<?php
//Start the session
if (version_compare(PHP_VERSION, "5.4.0") >= 0) {
    if(session_status() != PHP_SESSION_ACTIVE) {
        session_start();
    }
} else {
    session_start();
}
//For compatibility before PHP 5.3.0
if (!defined('__DIR__')) {
    class __FILE_CLASS__ {
        function __toString() {
            $X = debug_backtrace();
            return dirname($X[1]['file']);
        }
    }
    define('__DIR__', new __FILE_CLASS__);
}

require(__DIR__ . "/functions.php");
// ====================================================================================================// 
// ! Connect to MySQLi to allow escaping of inputs, and form processing.                               //
// ====================================================================================================//
$dbHostname = "localhost";
$dbUsername = "UserGiftForm";
$dbPassword = "Nev3rUseTh1sP4ssw0rdEverAgain!";
$dbDatabaseName = "OnlineGiftForm";
$mysqli = new mysqli($dbHostname, $dbUsername, $dbPassword, $dbDatabaseName);

if($mysqli->connect_errno) {
    printf("Connection failed: %s\n", $mysqli->connect_error());
    exit();
}

$isValid = true;
$errorMessage = "<h3>There was an error</h3><hr />";
// ====================================================================================================// 
// ! Do formKey() check to ensure that our form came form the right place                              //
// ====================================================================================================//
    //Create the formKey variable
    $formKey = new formKey();
    //let's check that it is correct
    if(!isset($_POST['form_key']) || !$formKey->validate()) {
        //Form key is invalid, show an error
        $isValid = false;
        $error = 'Form key error!';
    } else {
        //Do the rest of your validation here
        $error = 'No form key error!';
    }

    if($error == "Form key error!") {
        die("There was an error with the form key. For your safety, the form was not processed. Please return to the donation form, and try again. ");
    } else {

// ====================================================================================================// 
// ! Our formKey is correct, now let's get the form data                                               //
// ====================================================================================================//
        //get the donation type and then process the respective fields accordingly.
        $donationType = $_POST['donationType'];
        if($donationType == "oneTimeGift") {
            //Get the Gift Amount pieces
            //one time donations
            $totalGiftAmount = $_POST['oneTimeDonationValue'];
        } else if ($donationType == "recurringDonation") {
            //recurring donations
            $recurringGift = array(
                "donationAmount" => $_POST['recurringDonationValue'],
                "numberOfPayments" => $_POST['numberOfPayments'],
                "paymentFrequency" => $_POST['paymentFrequency']
            );
            //calculate their total gift. We want to do it again to avoid javascript related errors or changes.
            $totalGiftAmount = $recurringGift['donationAmount'] * $recurringGift['numberOfPayments'];
        } else {
            $isValid = false;
            $errorMessage .= "Sorry, there was an error. Please select one of the two types of donations. Please return to the first step and try again.<br />";
        }
        

  //create the array to store our checkbox values.
    //now let's get the values of the checkboxes starting with Scholarships
    if(!empty($_POST['list-items'])) {
        foreach($_POST['list-items'] as $listItem) {
        //check the values and add to the array accordingly
            switch ($listItem) {
                //Begin Scholarships
                case 'Good_Men_Good_Citizens':
                    $selected_items['GoodMenGoodCitizens'] = "Good Men, Good Citizens Scholarship";
                break;

                case 'Class_Scholarship':
                    $selected_items['ClassScholarship'] = "Class Scholarship";
                break;

                case 'Other_Scholarship':
                    $selected_items['OtherScholarship'] = $_POST['specinstr'];
                break;

                //Begins Academics
                case 'Atkinson_Museum':
                    $selected_items['AtkinsonMuseum'] = "Atkinson Museum";
                break;

                case 'Bortz_Library':
                    $selected_items['BortzLibrary'] = "Bortz Library";
                break;

                case 'Culture_and_Community':
                    $selected_items['CultureAndCommunity'] = "Culture and Community";
                break;

                case 'Wilson_Center':
                    $selected_items['WilsonCenter'] = "the Wilson Center";
                break;

                case 'Other_Academic_Area':
                    $selected_items['OtherAcademics'] = $_POST['specinstr'];
                break;

                //Begin Athletics
                case 'Baseball_Big_Hitters_Club':
                    $selected_items['BaseballBigHittersClub'] = "Baseball Big Hitters Club";
                break;

                case 'Basketball_Roundball_Club':
                    $selected_items['BasketballRoundballClub'] = "Basketball Roundball Club";
                break;

                case 'Cross_Country_Harriers':
                    $selected_items['CrossCOuntryHarriers'] = "Cross Country Harriers";
                break;

                case 'Everett_Stadium':
                    $selected_items['EverettStadium'] = "Everett Stadium";
                break;

                case 'Football_Gridiron_Club': 
                    $selected_items['FootballGridironClub'] = "Football Gridiron Club";
                break;

                case 'Golf_Hole_In_One_Club':
                    $selected_items['GolfHoleInOneClub'] = "Golf Hole In One Club";
                break;

                case 'Kirk_Athletic_Center':
                    $selected_items['KirkAthleticCenter'] = "Kirk Athletic Center";
                break;

                case 'Lacrosse_Face_Off_Club':
                    $selected_items['LacrosseFaceOffClub'] = "Lacrosse Face Off Club";
                break;

                case 'Rugby_Club':
                    $selected_items['RugbyClub'] = "Rugby Club";
                break;

                case 'Soccer_Goal_Club':
                    $selected_items['SoccerGoalClub'] = "Soccer Goal Club";
                break;

                case 'Swimming_Club':
                    $selected_items['SwimmingClub'] = "Swimming Club";
                break;

                case 'Tennis_Racquet_Club':
                    $selected_items['TennisRacquetClub'] = "Tennis Racquet Club";
                break;

                case 'unrestricted':
                    $selected_items['Unrestricted'] = "Unrestricted Hampden-Sydney Fund";
                break;

                default:
                  //they didn't select one of the given values, they changed a value (XSS) or did something mean. We don't wanna touch those fields or values.
                  break;
              }
          }
          //we also want to have the special instructions, just in case.
          $selected_items['SpecialInstructions'] = $_POST['specinstr'];
    } else {
        //it's empty :(
        $isValid = false;
        $errorMessage .= "You did not choose a fund to donate to! Please choose where you would like to donate to on Step 3.<br />";
    }
        $strippedPhoneNumber = preg_replace("/[^0-9]/", "", $_POST['usersPhoneNumber']);

        //make an array of the user information
        $userInfo = array(
            "firstName" => $_POST['usersFirstName'],
            "lastName" => $_POST['usersLastName'],
            "fullName" => $_POST['usersFirstName'] . " " . $_POST['usersLastName'],
            "classYear" => $_POST['usersClassYear'],
            "selectedClassYearScholarship" => $_POST['classYearScholarshipSelection'],
            "address1" => $_POST['usersStreetAddress'],
            "address2" => $_POST['usersSecondaryAddress'],
            "fullAddress" => $_POST['usersStreetAddress'] . "\n" . $_POST['usersSecondaryAddress'],
            "city" => $_POST['usersCity'],
            "fullState" => $_POST['usersState'],
            "state" => convert_state_to_abbreviation($_POST['usersState']),
            "zipcode" => $_POST['usersZip'],
            "fullCountry" => $_POST['usersCountry'],
            "country" => convert_country_to_abbreviation($_POST['usersCountry']),
            "phoneNumber" => $strippedPhoneNumber,
            "email" => $_POST['usersEmail'],
            "specialInstructions" => $_POST['specinstr'],
            "inMemoryOfSomeone" => $_POST['inMemoryOf'],
            "inHonorOfSomeone" => $_POST['inHonorOf']
        );

        //these numbers should be percentages. A maximum of 100, minimum of 0.
        //For class years it's classOfXXXXAllocation with XXXX being the year
        // ( if is_numric on the posted item returns true ? Divide it by 100 : Else convert string to number and do something)
        $userAllocations = array(
            "unrestrictedAllocation" => ($_POST['unrestricted-Allocation'] / 100),
            "goodMenGoodCitizensAllocation" => ($_POST['Good_Men_Good_Citizens-Allocation'] / 100),
            "classYearScholarshipAllocation" => ($_POST['Class_Of_' . $userInfo['selectedClassYearScholarship'] . '-Allocation'] / 100),
            "atkinsonMuseumAllocation" => ($_POST['Atkinson_Museum-Allocation'] / 100),
            "bortzLibraryAllocation" => ($_POST['Bortz_Library-Allocation'] / 100),
            "cultureAndCommunityAllocation" => ($_POST['Culture_and_Community-Allocation'] / 100),
            "wilsonCenterAllocation" => ($_POST['Wilson_Center-Allocation'] / 100),
            "baseballBigHittersClubAllocation" => ($_POST['Baseball_Big_Hitters_Club-Allocation'] / 100),
            "basketballRoundballClubAllocation" => ($_POST['Basketball_Roundball_Club-Allocation'] / 100),
            "crossCountryHarriersAllocation" => ($_POST['Cross_Country_Harriers-Allocation'] / 100),
            "everettStadiumAllocation" => ($_POST['Everett_Stadium-Allocation'] / 100),
            "footballGridironClubAllocation" => ($_POST['Football_Gridiron_Club-Allocation'] / 100),
            "golfHoleInOneClubAllocation" => ($_POST['Golf_Hole_In_One_Club-Allocation'] / 100),
            "kirkAthleticCenterAllocation" => ($_POST['Kirk_Athletic_Center-Allocation'] / 100),
            "lacrosseFaceOffClubAllocation" => ($_POST['Lacrosse_Face_Off_Club-Allocation'] / 100),
            "rugbyClubAllocation" => ($_POST['Rugby_Club-Allocation'] / 100),
            "soccerGoalClubAllocation" => ($_POST['Soccer_Goal_Club-Allocation'] / 100),
            "swimmingClubAllocation" => ($_POST['Swimming_Club-Allocation'] / 100),
            "tennisRacquetClubAllocation" => ($_POST['Tennis_Racquet_Club-Allocation'] / 100),
            "otherAllocation" => (($_POST['Other_Scholarship-Allocation'] + $_POST['Other_Academic-Allocation']) / 100)
            );

        //next we want to get the amount of the total gift that will go to any one place.
        //To do this:   $finalAmountToAllocation = ($totalGiftAmount * $allocationPercentage) Allocation percentages are in decimal form. 1 = 100% .5 = 50%, etc.
        $userDonationAmountBasedOnAllocations = array(
            "unrestrictedFundDonationAmount" => ($totalGiftAmount * $userAllocations['unrestrictedAllocation']),
            "goodMenGoodCitizensDonationAmount" => ($totalGiftAmount * $userAllocations['goodMenGoodCitizensAllocation']),
            "classYearScholarshipDonationAmount" => ($totalGiftAmount * $userAllocations['classYearScholarshipAllocation']),
            "atkinsonMuseumDonationAmount" => ($totalGiftAmount * $userAllocations['atkinsonMuseumAllocation']),
            "bortzLibraryDonationAmount" => ($totalGiftAmount * $userAllocations['bortzLibraryAllocation']),
            "cultureAndCommunityDonationAmount" => ($totalGiftAmount * $userAllocations['cultureAndCommunityAllocation']),
            "wilsonCenterDonationAmount" => ($totalGiftAmount * $userAllocations['wilsonCenterAllocation']),
            "baseballBigHittersClubDonationAmount" => ($totalGiftAmount * $userAllocations['baseballBigHittersClubAllocation']),
            "basketballRoundballClubDonationAmount" => ($totalGiftAmount * $userAllocations['basketballRoundballClubAllocation']),
            "crossCountryHarriersDonationAmount" => ($totalGiftAmount * $userAllocations['crossCountryHarriersAllocation']),
            "everettStadiumDonationAmount" => ($totalGiftAmount * $userAllocations['everettStadiumAllocation']),
            "footballGridironClubDonationAmount" => ($totalGiftAmount * $userAllocations['footballGridironClubAllocation']),
            "golfHoleInOneClubDonationAmount" => ($totalGiftAmount * $userAllocations['golfHoleInOneClubAllocation']),
            "kirkAthleticCenterDonationAmount" => ($totalGiftAmount * $userAllocations['kirkAthleticCenterAllocation']),
            "lacrosseFaceOffClubDonationAmount" => ($totalGiftAmount * $userAllocations['lacrosseFaceOffClubAllocation']),
            "rugbyClubDonationAmount" => ($totalGiftAmount * $userAllocations['rugbyClubAllocation']),
            "soccerGoalClubDonationAmount" => ($totalGiftAmount * $userAllocations['soccerGoalClubAllocation']),
            "swimmingClubDonationAmount" => ($totalGiftAmount * $userAllocations['swimmingClubAllocation']),
            "tennisRacquetClubDonationAmount" => ($totalGiftAmount * $userAllocations['tennisRacquetClubAllocation']),
            "otherDonationAmount" => ($totalGiftAmount * $userAllocations['otherAllocation']),
            );

        //Make an array of the credit card information
        $userCreditCardInfo = array(
            "nameOnCreditCard" => $mysqli->real_escape_string($_POST['nameOnCard']),
            "creditCardNumber" => $mysqli->real_escape_string($_POST['numberOnCard']),
            "creditCardType" => "",
            "creditCardSecurityCode" => $mysqli->real_escape_string($_POST['securityCodeOnCard']),
            "creditCardExpirationMonth" => $_POST['expirationMonthOnCard'],
            "creditCardExpirationYear" => $_POST['expirationYearOnCard']
        );
// ====================================================================================================// 
// ! Validate the data that we have taken from the form                                                //
// ====================================================================================================//
        if(check_Credit_Card($userCreditCardInfo['creditCardNumber'])) {
            $userCreditCardInfo['creditCardType'] = check_Credit_Card($userCreditCardInfo['creditCardNumber']);
        } else {
            $isValid = false;
            $errorMessage .= "We&rsquo;re sorry, but the credit card number that you entered was invalid. Please press the back button to change this number. <br />";
        }



        //check the user's email address
        if (check_email_address($userInfo['email']) != true) {
            $isValid = false;
            $errorMessage .= "The e-mail was invalid.<br />";
        }
// ====================================================================================================// 
// ! Store them all in a session in case we have to go back                                            //
// ====================================================================================================//
$_SESSION['userInfo'] = $userInfo;
$_SESSION['userDonationAmountBasedOnAllocations'] = $userDonationAmountBasedOnAllocations;
// ====================================================================================================// 
// ! Display the message of success or error                                                           //
// ====================================================================================================//
        if($isValid) {
            //we are already connected to the database.

            //Create a prepared statement step 2: prepare
            //INSERT INTO databasename.tablename (name of fields) VALUES (values that correspond)
            if(!($stmt = $mysqli->prepare("INSERT INTO `OnlineGiftForm`.`gift` (
                /*Item 1 - Name*/`name`, 
                /*Item 2 - Class Year*/`class`, 
                /*Item 3 - Full Address*/`address`, 
                /*Item 4 - City*/`city`, 
                /*Item 5 - State*/`state`, 
                /*Item 6 - Zip Code*/`zip`, 
                /*Item 7 - Country*/`country`, 
                /*Item 8 - Phone Number*/`hphone`, 
                /*Item 9 - Email Address*/`email`,
                /*Item 10 - Depreciated*//*`hear`, 
                /*Item 11 - ?*//*`otherexpl`, 
                /*Item 12 - ?*//*`applygift`, 
                /*Item 13 - ?*//*`other`, 
                /*Item 14 - Special Instruction*/`specinstr`,
                /*Item 15 - Credit Card Type*/`paymethod`, 
                /*Item 16 - Name on Credit Card*/`namecredit`, 
                /*Item 16.5 - Credit Card Number*/`cc1`, 
                /*Item 17 - Credit Card Expiration Month*/`expmo`, 
                /*Item 18 - Credit Card Expiration Year*/`expyr`, 
                /*Item 19 - Credit Card Security Code*/`ccv`, 
                /*Item 20 - ?*//*`endowmentamt`,
                /*Item 21 - ?*//*`academicamt`, 
                /*Item 22 - ?*//*`tigeramt`, 
                /*Item 23 - Culture and Community Donation Amount*/`cultureamt`, 
                /*Item 24 - Bortz Library Donation Amount*/`bortzamt`, 
                /*Item 25 - Everett Stadium Donation Amount*/`everettamt`, 
                /*Item 26 - Good Men Good Citizens Donation Amount*/`gmgcamt`,
                /*Item 27 - Kirk Athletic Center Donation Amount*/`kirkamt`, 
                /*Item 28 - Baseball Big Hitters Club Donation Amount*/`baseballamt`, 
                /*Item 29 - Basketball Roundball Club Donation Amount*/`basketballamt`, 
                /*Item 30 - Cross Country Harriers Donation Amount*/`countryamt`, 
                /*Item 31 - Golf Hole In One Club Donation Amount*/`golfamt`, 
                /*Item 32 - Football Gridiron Club Donation Amount*/`footballamt`, 
                /*Item 33 - Lacrosse Face Off Club Donation Amount*/`lacrosseamt`, 
                /*Item 34 - Soccer Goal Club Donation Amount*/`socceramt`, 
                /*Item 35 - Tennis Racquet Club Donation Amount*/`tennisamt`, 
                /*Item 36 - ?*//*`capitalamt`, 
                /*Item 37 - Wilson Center for Leadership Donation Amount*/`wilsonamt`, 
                /*Item 38 - Other (Special Instructions) Donation Amount*/`otheramt`, 
                /*Item 39 - Unrestricted Fund Donation Amount*/`unrestrictedamt`, 
                /*Item 40 - Atkinson Museum Donation Amount*/`museumamt`, 
                /*Item 41 - Class Scholarship Year Donation Amount*/`ClassScholarshipamt`, 
                /*Item 42 - Class Scholarship Year*/`ClassSchYear`, 
                /*Item 43 - ?*//*`alcoholamt`, 
                /*Item 44 - ?*//*`CEPEamt`, 
                /*Item 45 - ?*//*`referer`, 
                /*Item 46 - Swimming Club Donation Amount*/`swimmingamt`, 
                /*Item 47 - Rugby Club Donation Amount*/`rugbyamt`, 
                /*Item 48 - ?*//*`classroomsamt`, 
                /*Item 49 - Writing Center Donation Amount*//*`writingcenteramt`, 
                /*Item 50 - ?*//*`brinkleyamt`*/
                /*Item 51 - In Memory Of*/`memory`,
                /*Item 52 - In Honor Of*/`honor`) 
                VALUES (/*Item 1 - name*/ ?,
                    /*Item 2 - class year*/ ?,
                    /*Item 3 - full address*/ ?,
                    /*Item 4 - city*/ ?,
                    /*Item 5 - state*/ ?,
                    /*Item 6 - zip code*/ ?,
                    /*Item 7 - country*/ ?,
                    /*Item 8 - phone number*/ ?,
                    /*Item 9 - email*/ ?,
                    /*Item 14 - Special Instructions*/ ?,
                    /*Item 15 - type of credit card*/ ?,
                    /*Item 16 - name on card*/ ?, 
                    /*Item 16.5 - Credit Card Number*/ ENCODE(?, 'gift76'),
                    /*Item 17 - exp. month*/ ?,
                    /*Item 18 - exp. year*/ ?,
                    /*Item 19 - ccv*/ ?,
                    /*Item 23 - Culture and Community Amount*/ ?,
                    /*Item 24 - bortz library amt*/ ?,
                    /*Item 25 - everett stadium amount*/ ?,
                    /*Item 26 - Good Men Good Citizens Donation Amount*/ ?,
                    /*Item 27 - kirk athletic center amount*/ ?,
                    /*Item 28 - Baseball Big Hitters Club Amount*/ ?,
                    /*Item 29 - Basketball Roundball Club Amount*/ ?,
                    /*Item 30 - Cross Country Harriers Donation Amount*/ ?,
                    /*Item 31 - Golf Hole In One Club Donation Amount*/ ?,
                    /*Item 32 - Football Gridiron Club Amount*/ ?,
                    /*Item 33 - Lacrosse Faceoff Club Amount*/ ?,
                    /*Item 34 - Soccer Goal Club Donation Amount*/ ?,
                    /*Item 35 - Tennis Racquet Club Donation Amount*/ ?,
                    /*Item 37 - Wilson Center Amount*/ ?,
                    /*Item 38 - Other (Special Instructions) Amount*/ ?,
                    /*Item 39 - Unrestricted fund amount*/ ?,
                    /*Item 40 - Atkinson Museum Amount*/ ?,
                    /*Item 41 - Class Year Donation Amount*/ ?,
                    /*Item 42 - Class Scholarship Year*/ ?,
                    /*Item 46 - Swimming Club Donation Amount*/ ?,
                    /*Item 47 - Rugby Club Donation Amount*/ ?,
                    /*Item 51 - In Memory Of*/ ?,
                    /*Item 52 - In Honor Of*/ ?);"))) {
                echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
                die();
            }

            //Step 2: Bind our parameters
            // i - integer | d - double | s - string | b - blob
            if(!$stmt->bind_param("sssssssssssssssssssssssssssssssssssssss",
                $userInfo['fullName'], /*Item 1 - s*/
                $userInfo['classYear'], /*Item 2 - s*/
                $userInfo['fullAddress'], /*Item 3 - s*/
                $userInfo['city'], /*Item 4 - s*/
                $userInfo['state'], /*Item 5 - s*/
                $userInfo['zipcode'], /*Item 6 - s*/
                $userInfo['country'], /*Item 7 - s*/
                $userInfo['phoneNumber'], /*Item 8 - s*/
                $userInfo['email'], /*Item 9 - s*/
                /*$otherExplanation,
                $applyGift,
                $other,*/
                $userInfo['specialInstructions'], /*Item 14 - s*/
                $userCreditCardInfo['creditCardType'], /*Item 15 - s*/
                $userCreditCardInfo['nameOnCreditCard'], /*Item 16 - s*/
                $userCreditCardInfo['creditCardNumber'], /*Item 16.5 - s*/
                $userCreditCardInfo['creditCardExpirationMonth'], /*Item 17 - s*/
                $userCreditCardInfo['creditCardExpirationYear'], /*Item 18 - s*/
                $userCreditCardInfo['creditCardSecurityCode'], /*Item 19 - s*/
                /*$endowmentAmount,
                $academicAmount,
                $tigerAmount,*/
                $userDonationAmountBasedOnAllocations['cultureAndCommunityDonationAmount'], /*Item 23 - s*/
                $userDonationAmountBasedOnAllocations['bortzLibraryDonationAmount'], /*Item 24 - s*/
                $userDonationAmountBasedOnAllocations['everettStadiumDonationAmount'], /*Item 25 - s*/
                $userDonationAmountBasedOnAllocations['goodMenGoodCitizensDonationAmount'], /*Item 26 - s*/
                $userDonationAmountBasedOnAllocations['kirkAthleticCenterDonationAmount'], /*Item 27 - s*/
                $userDonationAmountBasedOnAllocations['baseballBigHittersClubDonationAmount'], /*Item 28 - s*/
                $userDonationAmountBasedOnAllocations['basketballRoundballClubDonationAmount'], /*Item 29 - s*/
                $userDonationAmountBasedOnAllocations['crossCountryHarriersDonationAmount'], /*Item 30 - s*/
                $userDonationAmountBasedOnAllocations['golfHoleInOneClubDonationAmount'], /*Item 31 - s*/
                $userDonationAmountBasedOnAllocations['footballGridironClubDonationAmount'], /*Item 32 - s*/
                $userDonationAmountBasedOnAllocations['lacrosseFaceOffClubDonationAmount'], /*Item 33 - s*/
                $userDonationAmountBasedOnAllocations['soccerGoalClubDonationAmount'], /*Item 34 - s*/
                $userDonationAmountBasedOnAllocations['tennisRacquetClubDonationAmount'], /*Item 35 - s*/
                /*$capitalAmount,*/
                $userDonationAmountBasedOnAllocations['wilsonCenterDonationAmount'], /*Item 37 - s*/
                $userDonationAmountBasedOnAllocations['otherDonationAmount'], /*Item 38 - s*/
                $userDonationAmountBasedOnAllocations['unrestrictedFundDonationAmount'], /*Item 39 - s*/
                $userDonationAmountBasedOnAllocations['atkinsonMuseumDonationAmount'], /*Item 40 - s*/
                $userDonationAmountBasedOnAllocations['classYearScholarshipDonationAmount'], /*Item 41 - s*/
                $userInfo['selectedClassYearScholarship'], /*Item 42 - s*//*
                $alcoholAmount,
                $CEPEAmount,
                $referer,*/
                $userDonationAmountBasedOnAllocations['swimmingClubDonationAmount'], /*Item 46 - s*/
                $userDonationAmountBasedOnAllocations['rugbyClubDonationAmount'], /*Item 47 - s*/
                /*$classroomsAmount,
                $writingCenterAmount,
                $brinkleyAmount*/
                $userInfo['inMemoryOfSomeone'], /*Item 51 - s*/
                $userInfo['inHonorOfSomeone'] /*Item 52 - s*/)) {
                    echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
                    die();
            }

            //Step 3: Execute
            if(!$stmt->execute()) {
                echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
                die();
            }

            //Step 4: Close the statement
            $stmt->close();

            echo "<p>We have received your gift and will email a summary to you at " . $userInfo['email'] .". You will also receive an acknowledgment letter and tax receipt in the mail. If you have any questions, please contact the Office of Institutional Advancement at <a href=\"tel:18008651776\" title=\"Call Us Toll-Free\">1&ndash;800&ndash;865&ndash;1776</a>.</p>";
            $to = $userInfo['email'];
            $headers = 'From: noreply@hsc.edu' . "\r\n" . 'Reply-To:webmaster@hsc.edu' . 'X-Mailer: PHP/' . phpversion();
            $subject = "Thank you for your gift!";
            $message = "Your gift was received. On behalf of Hampden-Sydney, we would like to thank you for your donation.";
            //we have composed our message. Now let's send it on. Commented out for development sake.
            //if(mail($to, $subject, $message, $headers)) {
                //echo("<p>Message sent!</p>");
            //} else {
            //echo "<p>Message delivery failed :( </p>";
        //}
        } else {
            //print_r($userInfo); to check if error in what's being put into the database
            //print_r($userDonationAmountBasedOnAollocations);
            //print_r($userCreditCardInfo);
            echo "<p class=\"centerText\">".$errorMessage."</p>";
        }
    }
    //close the database connection.
    $mysqli->close();
?>